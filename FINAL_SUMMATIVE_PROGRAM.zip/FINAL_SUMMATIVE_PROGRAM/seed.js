const mongoose = require('mongoose');
const Plant = require('./models/plant');

mongoose.connect('mongodb://localhost:27017/plantdb', {
    useNewUrlParser: true,
    useUnifiedTopology: true
});


const plants = [
    { name: "Bulba Fern", light: "Bright indirect", water: "Once a week", image: "/images/bulba-fern.png" },
    { name: "Pika Succulent", light: "Full sun", water: "Every 2 weeks", image: "/images/pika-succ.png" },
    { name: "Squirtle Ivy", light: "Partial shade", water: "Twice a week", image: "/images/squirtle-ivy.png" },
    { name: "Charmander Cactus", light: "Full sun", water: "Once a month", image: "/images/charmander-cactus.png" },
    { name: "Oddish Pothos", light: "Low to bright indirect", water: "Once a week", image: "/images/oddish-pothos.png" },
    { name: "Chikorita Fern", light: "Bright indirect", water: "Once a week", image: "/images/chikorita-fern.png" },
    { name: "Turtwig Moss", light: "Low light", water: "Keep moist", image: "/images/turtwig-moss.png" },
    { name: "Leafeon Leaf", light: "Bright indirect", water: "Every 5 days", image: "/images/leafeon-leaf.png" },
    { name: "Ludicolo Lily", light: "Medium light", water: "Twice a week", image: "/images/ludicolo-lily.png" },
    { name: "Sunkern Sunflower", light: "Full sun", water: "Every 3 days", image: "/images/sunkern-sunflower.png" },
];

const seedDB = async () => {
    await Plant.deleteMany({});
    await Plant.insertMany(plants);
    mongoose.connection.close();
    console.log("Database seeded!");
};

seedDB();
